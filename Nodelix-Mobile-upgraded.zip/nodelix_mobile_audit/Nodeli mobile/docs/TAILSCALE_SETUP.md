# Tailscale Support — Nodelix Mobile v1.1.0

## Setup di Server (NodelixcoreOS)
1. Install Tailscale di perangkat server (Termux/Linux)
2. `tailscale up` lalu login
3. Set `TAILSCALE_ENABLE=true` di `.env`
4. Set `TAILSCALE_IP=100.x.y.z` (IP Tailscale server) atau biarkan kosong untuk auto-detect

## Setup di App Mobile
1. Install Tailscale di HP
2. `tailscale up` (login dengan akun yang sama)
3. Buka Nodelix Mobile → Settings → Server
4. Masukkan IP Tailscale server (100.x.y.z) atau MagicDNS (`<host>.ts.net`)
5. Port: sama dengan PORT di .env (default 3000)

## Keamanan
- Tailscale overlay tidak memerlukan port-forward di router
- Akses terbatas ke perangkat yang masuk satu Tailnet (autentikasi akun Tailscale)
- Endpoint tetap memverifikasi sesi mobile (ECDSA P-256 + Bearer)
